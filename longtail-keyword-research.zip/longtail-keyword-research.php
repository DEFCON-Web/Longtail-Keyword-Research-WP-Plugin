<?php
/**
 * Plugin Name:       LongTail Keyword Research
 * Plugin URI:        https://github.com/DEFCON-Web/Longtail-Keyword-Research-WP-Plugin
 * Description:       Discover low-competition long-tail keywords with search volume estimates. Includes GitHub release-based auto-update system.
 * Version:           1.0.0
 * Requires at least: 5.0
 * Tested up to:      6.7
 * Requires PHP:      7.4
 * Author:            DEFCON
 * Author URI:        https://github.com/DEFCON-Web/Longtail-Keyword-Research-WP-Plugin
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       longtail-keyword-research
 * Domain Path:       /languages
 */

defined('ABSPATH') || exit;

define('LTKR_PLUGIN_VERSION', '1.0.0');
define('LTKR_PLUGIN_FILE', __FILE__);
define('LTKR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LTKR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('LTKR_DB_TABLE', 'lkw_search_history');

spl_autoload_register(function ($class) {
    $prefix = 'LTKR\\';
    if (strpos($class, $prefix) !== 0) return;
    $relative = substr($class, strlen($prefix));
    $file = LTKR_PLUGIN_DIR . 'includes/class-' . strtolower(str_replace('_', '-', $relative)) . '.php';
    if (file_exists($file)) require $file;
});

register_activation_hook(__FILE__, function () {
    require_once LTKR_PLUGIN_DIR . 'includes/class-keyword-research.php';
    LTKR\Keyword_Research::activate();
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('ltkr_daily_maintenance');
});

add_action('plugins_loaded', function () {
    new LTKR\Updater();
    if (is_admin()) {
        new LTKR\Admin();
    }
});

add_action('ltkr_daily_maintenance', function () {
    global $wpdb;
    $table = $wpdb->prefix . LTKR_DB_TABLE;
    $wpdb->query("DELETE FROM $table WHERE search_date < DATE_SUB(NOW(), INTERVAL 90 DAY)");
    $wpdb->query("OPTIMIZE TABLE $table");
});
