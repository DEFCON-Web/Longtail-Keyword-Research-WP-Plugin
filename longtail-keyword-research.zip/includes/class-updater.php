<?php
namespace LTKR;

defined('ABSPATH') || exit;

class Updater {
    private $file;
    private $plugin;
    private $basename;
    private $github_repo;
    private $github_api_url;
    private $slug;

    public function __construct() {
        $this->file          = LTKR_PLUGIN_FILE;
        $this->plugin        = get_file_data($this->file, ['Version' => 'Version']);
        $this->basename      = plugin_basename($this->file);
        $this->slug          = dirname($this->basename);
        $this->github_repo   = 'DEFCON-Web/Longtail-Keyword-Research-WP-Plugin';
        $this->github_api_url = 'https://api.github.com/repos/' . $this->github_repo . '/releases';

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 10, 3);
        add_filter('upgrader_post_install', [$this, 'after_install'], 10, 3);
    }

    public function check_update($transient) {
        if (empty($transient->checked)) return $transient;

        $release = $this->fetch_latest_release();
        if (!$release || empty($release->tag_name)) return $transient;

        $remote_version = ltrim($release->tag_name, 'v');
        $current_version = $this->plugin['Version'];

        if (version_compare($remote_version, $current_version, '>')) {
            $zip_url = $this->get_release_zip_url($release);
            if (!$zip_url) return $transient;

            $license_valid = $this->is_license_valid();

            $transient->response[$this->basename] = (object) [
                'slug'        => $this->slug,
                'plugin'      => $this->basename,
                'new_version' => $remote_version,
                'package'     => $license_valid ? $zip_url : '',
                'url'         => 'https://github.com/' . $this->github_repo,
                'tested'      => $release->tested ?? '6.7',
                'requires_php'=> $release->requires_php ?? '7.4',
                'icons'       => [],
                'banners'     => [],
            ];

            if (!$license_valid) {
                $transient->response[$this->basename]->package = false;
                $transient->response[$this->basename]->upgrade_notice = 'Enter a valid license key on the settings page to enable one-click updates.';
            }
        }

        return $transient;
    }

    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== $this->slug) {
            return $result;
        }

        $release = $this->fetch_latest_release();
        if (!$release) return $result;

        $zip_url = $this->get_release_zip_url($release);

        return (object) [
            'name'          => 'LongTail Keyword Research',
            'slug'          => $this->slug,
            'version'       => ltrim($release->tag_name, 'v'),
            'author'        => '<a href="https://github.com/DEFCON-Web">DEFCON</a>',
            'author_profile'=> 'https://github.com/DEFCON-Web',
            'last_updated'  => $release->published_at,
            'homepage'      => 'https://github.com/' . $this->github_repo,
            'short_description' => $release->body ? wp_trim_words($release->body, 30) : '',
            'sections'      => [
                'description' => $release->body ? nl2br(esc_html($release->body)) : 'No description provided.',
                'changelog'   => $release->body ? nl2br(esc_html($release->body)) : 'See GitHub releases for changelog.',
            ],
            'download_link' => $zip_url,
            'requires'      => '5.0',
            'tested'        => '6.7',
            'requires_php'  => '7.4',
        ];
    }

    public function after_install($response, $hook_extra, $result) {
        global $wp_filesystem;
        $plugin_folder = WP_PLUGIN_DIR . '/' . dirname($this->basename);
        $destination  = WP_PLUGIN_DIR . '/' . $this->slug;

        if ($wp_filesystem && $result['destination']) {
            $move_result = $wp_filesystem->move($result['destination'], $destination);
            if ($move_result) {
                $result['destination'] = $destination;
            }
        }

        return $result;
    }

    private function fetch_latest_release() {
        $cache_key = 'ltkr_github_release';
        $cached = get_transient($cache_key);
        if ($cached !== false) return $cached;

        $response = wp_remote_get($this->github_api_url, [
            'timeout'   => 15,
            'headers'   => ['Accept' => 'application/vnd.github.v3+json'],
            'user-agent'=> 'WordPress/' . get_bloginfo('version') . '; ' . home_url(),
        ]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return null;
        }

        $releases = json_decode(wp_remote_retrieve_body($response));
        if (!is_array($releases) || empty($releases)) return null;

        $latest = $releases[0];
        set_transient($cache_key, $latest, 6 * HOUR_IN_SECONDS);

        return $latest;
    }

    private function get_release_zip_url($release) {
        if (!empty($release->assets) && isset($release->assets[0]->browser_download_url)) {
            return $release->assets[0]->browser_download_url;
        }
        if (!empty($release->zipball_url)) {
            return $release->zipball_url;
        }
        return '';
    }

    private function is_license_valid() {
        $license_key = get_option('ltkr_license_key', '');
        if (empty($license_key)) return false;

        $cached = get_transient('ltkr_license_status');
        if ($cached !== false) return $cached === 'valid';

        $response = wp_remote_post('https://api.github.com/repos/' . $this->github_repo . '/releases', [
            'timeout' => 10,
            'headers' => [
                'Accept'       => 'application/vnd.github.v3+json',
                'User-Agent'   => 'WordPress/' . get_bloginfo('version'),
            ],
        ]);

        if (is_wp_error($response)) return true;
        $status = wp_remote_retrieve_response_code($response) === 200;
        set_transient('ltkr_license_status', $status ? 'valid' : 'invalid', DAY_IN_SECONDS);

        return $status;
    }
}
