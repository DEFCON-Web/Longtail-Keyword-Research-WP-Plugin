<?php
namespace LTKR;

defined('ABSPATH') || exit;

class Keyword_Research {

    public static function activate() {
        self::create_table();
        if (!wp_next_scheduled('ltkr_daily_maintenance')) {
            wp_schedule_event(time(), 'daily', 'ltkr_daily_maintenance');
        }
    }

    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . LTKR_DB_TABLE;
        $charset    = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            keyword    VARCHAR(500) NOT NULL,
            results    LONGTEXT NOT NULL,
            search_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_keyword (keyword(100)),
            INDEX idx_date (search_date)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function search($input_keyword) {
        $input_keyword = trim(sanitize_text_field($input_keyword));
        if (empty($input_keyword)) {
            return new \WP_Error('empty', 'Please enter a keyword.');
        }

        $suggestions = $this->get_google_suggestions($input_keyword);
        $variations  = $this->generate_long_tail_variations($input_keyword);
        $all_keywords = array_unique(array_merge($suggestions, $variations));

        if (empty($all_keywords)) {
            $all_keywords = $this->fallback_keywords($input_keyword);
        }

        $results = [];
        foreach ($all_keywords as $kw) {
            $kw = trim($kw);
            if (empty($kw) || strlen($kw) < 5) continue;

            $metrics = $this->estimate_metrics($kw, $input_keyword);
            $results[] = $metrics;
        }

        usort($results, function ($a, $b) {
            if ($a['competition_score'] !== $b['competition_score']) {
                return $a['competition_score'] - $b['competition_score'];
            }
            return $b['volume'] - $a['volume'];
        });

        $results = array_slice($results, 0, 50);
        $this->save_history($input_keyword, $results);

        return $results;
    }

    private function get_google_suggestions($keyword) {
        $suggestions = [];
        $url = 'https://suggestqueries.google.com/complete/search?output=toolbar&hl=en&q=' . rawurlencode($keyword);

        $response = wp_remote_get($url, [
            'timeout' => 10,
            'headers' => ['User-Agent' => 'Mozilla/5.0'],
        ]);

        if (is_wp_error($response)) return $suggestions;

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) return $suggestions;

        $xml = simplexml_load_string($body);
        if ($xml === false) return $suggestions;

        foreach ($xml->CompleteSuggestion as $suggestion) {
            $suggestions[] = (string) $suggestion->suggestion['data'];
        }

        return $suggestions;
    }

    private function generate_long_tail_variations($keyword) {
        $modifiers = [
            'how to', 'best', 'top', 'vs', 'vs.',
            'for beginners', 'advanced', 'guide', 'tutorial',
            'near me', 'online', 'free', 'cheap', 'affordable',
            'review', 'reviews', 'alternatives', 'pricing',
            'what is', 'why', 'benefits of', 'types of',
            'with', 'without', 'for', 'in',
            'step by step', 'complete', 'ultimate',
            '2025', '2026', '2024',
            'tools', 'software', 'services', 'courses',
            'ideas', 'tips', 'examples', 'template',
            'comparison', 'features', 'pros and cons',
            'beginner', 'professional', 'expert',
        ];

        $variations = [];

        foreach ($modifiers as $mod) {
            $variations[] = "$mod $keyword";
            $variations[] = "$keyword $mod";
        }

        $words = explode(' ', $keyword);
        if (count($words) >= 2) {
            for ($i = 1; $i < count($words); $i++) {
                $phrase = implode(' ', array_slice($words, $i));
                if (!empty($phrase)) {
                    $variations[] = $phrase;
                    $variations[] = "how to $phrase";
                    $variations[] = "best $phrase";
                }
            }
        }

        return array_unique($variations);
    }

    private function fallback_keywords($keyword) {
        $words = explode(' ', $keyword);
        $base = $words[0];
        $fallback = [
            "$base guide",
            "$base tutorial",
            "$base tools",
            "best $base",
            "$base for beginners",
            "$base review",
            "how to use $base",
            "$base alternatives",
            "what is $base",
            "$base features",
            "$base pricing",
            "$base vs",
            "$base tips",
            "$base ideas",
            "$base examples",
        ];
        if (count($words) > 1) {
            $rest = implode(' ', array_slice($words, 1));
            $fallback[] = "$base $rest guide";
            $fallback[] = "$base $rest tips";
            $fallback[] = "best $base $rest";
            $fallback[] = "how to $base $rest";
        }
        return $fallback;
    }

    private function estimate_metrics($keyword, $seed_keyword) {
        $word_count       = str_word_count($keyword);
        $char_count       = strlen($keyword);
        $seed_words       = explode(' ', strtolower($seed_keyword));
        $keyword_lower    = strtolower($keyword);

        $long_tail_score = 0;
        $long_tail_score += min($word_count * 5, 40);
        $long_tail_score += $char_count > 30 ? 15 : ($char_count > 20 ? 10 : 0);

        $modifier_words = ['how','what','why','best','top','guide','tutorial','review','vs','near','free','cheap'];
        foreach ($modifier_words as $mw) {
            if (strpos($keyword_lower, $mw) !== false) {
                $long_tail_score += 3;
            }
        }

        if ($word_count >= 4) $long_tail_score += 10;
        if ($word_count >= 5) $long_tail_score += 10;

        $competition_raw = max(1, 100 - $long_tail_score);
        $competition_level = $this->competition_label($competition_raw);

        $volume = $this->estimate_volume($keyword, $long_tail_score);
        $cpc = round(mt_rand(50, 500) / 100 - ($competition_raw / 200), 2);
        $cpc = max(0.10, $cpc);

        return [
            'keyword'           => $keyword,
            'volume'            => $volume,
            'competition'       => $competition_level,
            'competition_score' => $competition_raw,
            'cpc'               => $cpc,
            'word_count'        => $word_count,
            'is_long_tail'      => $word_count >= 3,
            'trending'          => $this->is_trending($keyword),
        ];
    }

    private function competition_label($score) {
        if ($score <= 25) return 'Very Low';
        if ($score <= 45) return 'Low';
        if ($score <= 65) return 'Medium';
        if ($score <= 85) return 'High';
        return 'Very High';
    }

    private function estimate_volume($keyword, $long_tail_score) {
        $base = wp_rand(10, 200);
        if ($long_tail_score > 50) {
            $base = wp_rand(5, 80);
        } elseif ($long_tail_score > 30) {
            $base = wp_rand(10, 150);
        }
        if (preg_match('/\b(2025|2026|2024)\b/', $keyword)) {
            $base += wp_rand(20, 100);
        }
        return $base;
    }

    private function is_trending($keyword) {
        return preg_match('/\b(2025|2026|new|trending|latest|best)\b/i', $keyword) && wp_rand(1, 3) > 1;
    }

    public function get_history($limit = 30) {
        global $wpdb;
        $table = $wpdb->prefix . LTKR_DB_TABLE;
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM $table ORDER BY search_date DESC LIMIT %d", $limit)
        );
    }

    public function save_history($keyword, $results) {
        global $wpdb;
        $table = $wpdb->prefix . LTKR_DB_TABLE;

        $wpdb->insert($table, [
            'keyword'     => $keyword,
            'results'     => wp_json_encode($results),
            'search_date' => current_time('mysql'),
        ]);
    }

    public function clear_history() {
        global $wpdb;
        $table = $wpdb->prefix . LTKR_DB_TABLE;
        return $wpdb->query("TRUNCATE TABLE $table");
    }
}
