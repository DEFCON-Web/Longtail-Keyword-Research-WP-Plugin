<?php
namespace LTKR;

defined('ABSPATH') || exit;

class Admin {

    private $keyword_research;

    public function __construct() {
        $this->keyword_research = new Keyword_Research();

        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_ltkr_search_keywords', [$this, 'ajax_search_keywords']);
        add_action('wp_ajax_ltkr_clear_history', [$this, 'ajax_clear_history']);
        add_action('wp_ajax_ltkr_save_license', [$this, 'ajax_save_license']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function register_settings() {
        register_setting('ltkr_settings_group', 'ltkr_license_key', 'sanitize_text_field');
    }

    public function add_admin_menu() {
        add_menu_page(
            'LongTail Keyword Research',
            'LongTail Keyword Research',
            'manage_options',
            'longtail-keyword-research',
            [$this, 'render_main_page'],
            'dashicons-search',
            30
        );

        add_submenu_page(
            'longtail-keyword-research',
            'Settings',
            'Settings',
            'manage_options',
            'longtail-keyword-research-settings',
            [$this, 'render_settings_page']
        );
    }

    public function enqueue_assets($hook) {
        if (strpos($hook, 'longtail-keyword-research') === false) return;

        wp_enqueue_style(
            'ltkr-admin',
            LTKR_PLUGIN_URL . 'assets/css/admin.css',
            [],
            LTKR_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'ltkr-admin',
            LTKR_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            LTKR_PLUGIN_VERSION,
            true
        );

        wp_localize_script('ltkr-admin', 'ltkr_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('ltkr_nonce'),
            'searching'=> 'Researching keywords...',
            'error_msg'=> 'Something went wrong. Please try again.',
        ]);
    }

    public function render_main_page() {
        $history = $this->keyword_research->get_history();
        ?>
        <div class="wrap ltkr-wrap">
            <h1>LongTail Keyword Research</h1>
            <p class="ltkr-subtitle">Enter a seed keyword to discover low-competition long-tail keywords.</p>

            <div class="ltkr-search-box">
                <input type="text" id="ltkr-keyword-input" class="ltkr-input" placeholder="e.g., digital marketing, web design, yoga tips..." autocomplete="off" />
                <button id="ltkr-search-btn" class="button button-primary ltkr-btn">Research Keywords</button>
                <span class="spinner ltkr-spinner"></span>
            </div>

            <div id="ltkr-results-area" class="ltkr-results" style="display:none;">
                <h2>Results <span id="ltkr-result-count" class="ltkr-count"></span></h2>
                <div class="ltkr-table-wrap">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Keyword</th>
                                <th class="ltkr-num">Est. Volume</th>
                                <th>Competition</th>
                                <th class="ltkr-num">CPC ($)</th>
                                <th class="ltkr-num">Words</th>
                                <th>Type</th>
                                <th>Trending</th>
                            </tr>
                        </thead>
                        <tbody id="ltkr-results-body"></tbody>
                    </table>
                </div>
            </div>

            <div id="ltkr-error-area" class="ltkr-error" style="display:none;"></div>

            <div class="ltkr-history">
                <h2>
                    Search History
                    <button id="ltkr-clear-history-btn" class="button ltkr-btn-danger">Clear History</button>
                    <span class="spinner ltkr-spinner-history"></span>
                </h2>
                <?php if (empty($history)): ?>
                    <p class="ltkr-empty">No searches yet.</p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Keyword</th>
                                <th>Results</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($history as $row): ?>
                                <?php $res = json_decode($row->results, true); ?>
                                <tr>
                                    <td><strong><?php echo esc_html($row->keyword); ?></strong></td>
                                    <td><?php echo is_array($res) ? count($res) : 0; ?> keywords</td>
                                    <td><?php echo esc_html($row->search_date); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    public function render_settings_page() {
        $license = get_option('ltkr_license_key', '');
        ?>
        <div class="wrap ltkr-wrap">
            <h1>LongTail Keyword Research — Settings</h1>
            <form method="post" action="options.php" class="ltkr-settings-form">
                <?php settings_fields('ltkr_settings_group'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="ltkr_license_key">License Key</label></th>
                        <td>
                            <input type="text" id="ltkr_license_key" name="ltkr_license_key"
                                   value="<?php echo esc_attr($license); ?>" class="regular-text" />
                            <p class="description">Enter your license key to enable one-click updates from GitHub.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save License Key'); ?>
            </form>

            <hr />

            <div class="ltkr-settings-info">
                <h3>Plugin Information</h3>
                <table class="widefat fixed striped">
                    <tbody>
                        <tr><td><strong>Plugin Version</strong></td><td><?php echo esc_html(LTKR_PLUGIN_VERSION); ?></td></tr>
                        <tr><td><strong>Author</strong></td><td>DEFCON</td></tr>
                        <tr><td><strong>Plugin URI</strong></td><td><a href="https://github.com/DEFCON-Web/Longtail-Keyword-Research-WP-Plugin" target="_blank">https://github.com/DEFCON-Web/Longtail-Keyword-Research-WP-Plugin</a></td></tr>
                        <tr><td><strong>Author URI</strong></td><td><a href="https://github.com/DEFCON-Web" target="_blank">https://github.com/DEFCON-Web</a></td></tr>
                        <tr><td><strong>Update Server</strong></td><td>GitHub Releases (<code>DEFCON-Web/Longtail-Keyword-Research-WP-Plugin</code>)</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function ajax_search_keywords() {
        $this->verify_request();

        $keyword = isset($_POST['keyword']) ? sanitize_text_field($_POST['keyword']) : '';
        if (empty($keyword)) {
            wp_send_json_error(['message' => 'Please enter a keyword.']);
        }

        $results = $this->keyword_research->search($keyword);
        if (is_wp_error($results)) {
            wp_send_json_error(['message' => $results->get_error_message()]);
        }

        wp_send_json_success([
            'keyword' => $keyword,
            'results' => $results,
            'total'   => count($results),
        ]);
    }

    public function ajax_clear_history() {
        $this->verify_request();

        $deleted = $this->keyword_research->clear_history();
        if ($deleted !== false) {
            wp_send_json_success(['message' => 'History cleared.']);
        } else {
            wp_send_json_error(['message' => 'Could not clear history.']);
        }
    }

    public function ajax_save_license() {
        $this->verify_request();

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.']);
        }

        $license = isset($_POST['license_key']) ? sanitize_text_field($_POST['license_key']) : '';
        update_option('ltkr_license_key', $license);

        wp_send_json_success(['message' => 'License key saved.']);
    }

    private function verify_request() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ltkr_nonce')) {
            wp_send_json_error(['message' => 'Security check failed.']);
        }
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized.']);
        }
    }
}
