<?php
defined('WP_UNINSTALL_PLUGIN') || exit;

global $wpdb;

$table_name = $wpdb->prefix . 'lkw_search_history';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

delete_option('ltkr_license_key');
delete_option('ltkr_license_status');

wp_clear_scheduled_hook('ltkr_daily_maintenance');
