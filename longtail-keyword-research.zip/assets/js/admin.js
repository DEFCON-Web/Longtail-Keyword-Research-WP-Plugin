(function ($) {
    'use strict';

    var $input = $('#ltkr-keyword-input');
    var $btn   = $('#ltkr-search-btn');
    var $spinner = $('.ltkr-spinner');
    var $resultsArea = $('#ltkr-results-area');
    var $resultsBody = $('#ltkr-results-body');
    var $resultCount = $('#ltkr-result-count');
    var $errorArea = $('#ltkr-error-area');
    var $clearBtn = $('#ltkr-clear-history-btn');
    var $histSpinner = $('.ltkr-spinner-history');

    function getCompetitionHtml(level) {
        var cls = 'ltkr-comp-low';
        if (level === 'Very Low')  cls = 'ltkr-comp-verylow';
        else if (level === 'Low')  cls = 'ltkr-comp-low';
        else if (level === 'Medium') cls = 'ltkr-comp-medium';
        else if (level === 'High') cls = 'ltkr-comp-high';
        else if (level === 'Very High') cls = 'ltkr-comp-veryhigh';
        return '<span class="' + cls + '">' + level + '</span>';
    }

    function renderResults(keyword, results) {
        $resultsBody.empty();

        $.each(results, function (i, r) {
            var competition = getCompetitionHtml(r.competition);
            var trending = r.trending
                ? '<span class="ltkr-trending-yes">Trending</span>'
                : '<span class="ltkr-trending-no">—</span>';
            var typeLabel = r.is_long_tail
                ? '<span class="ltkr-type-longtail">Long-tail</span>'
                : 'Short';

            $resultsBody.append(
                '<tr>' +
                    '<td>' + escHtml(r.keyword) + '</td>' +
                    '<td class="ltkr-num">' + r.volume + '</td>' +
                    '<td>' + competition + '</td>' +
                    '<td class="ltkr-num">$' + r.cpc.toFixed(2) + '</td>' +
                    '<td class="ltkr-num">' + r.word_count + '</td>' +
                    '<td>' + typeLabel + '</td>' +
                    '<td>' + trending + '</td>' +
                '</tr>'
            );
        });

        $resultCount.text(results.length + ' keywords');
        $resultsArea.show();
        $errorArea.hide();
    }

    function escHtml(str) {
        return $('<div>').text(str).html();
    }

    function doSearch() {
        var keyword = $input.val().trim();
        if (!keyword) {
            $input.focus();
            return;
        }

        $btn.prop('disabled', true);
        $spinner.addClass('is-active');
        $resultsArea.hide();
        $errorArea.hide();

        $.post(ltkr_ajax.ajax_url, {
            action:  'ltkr_search_keywords',
            keyword: keyword,
            nonce:   ltkr_ajax.nonce
        }, function (resp) {
            if (resp.success) {
                renderResults(resp.data.keyword, resp.data.results);
                if ($('.ltkr-history .ltkr-empty').length) {
                    location.reload();
                }
            } else {
                $errorArea.text(resp.data.message || ltkr_ajax.error_msg).show();
            }
        }).fail(function () {
            $errorArea.text(ltkr_ajax.error_msg).show();
        }).always(function () {
            $btn.prop('disabled', false);
            $spinner.removeClass('is-active');
        });
    }

    $btn.on('click', doSearch);
    $input.on('keydown', function (e) {
        if (e.keyCode === 13) doSearch();
    });

    $clearBtn.on('click', function () {
        if (!confirm('Are you sure you want to clear all search history? This will permanently delete all data from the database.')) {
            return;
        }

        $clearBtn.prop('disabled', true);
        $histSpinner.addClass('is-active');

        $.post(ltkr_ajax.ajax_url, {
            action: 'ltkr_clear_history',
            nonce:  ltkr_ajax.nonce
        }, function (resp) {
            if (resp.success) {
                location.reload();
            } else {
                alert(resp.data.message || 'Could not clear history.');
            }
        }).fail(function () {
            alert('Could not clear history.');
        }).always(function () {
            $clearBtn.prop('disabled', false);
            $histSpinner.removeClass('is-active');
        });
    });

})(jQuery);
